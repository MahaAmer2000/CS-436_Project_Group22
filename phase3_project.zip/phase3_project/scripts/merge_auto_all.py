#======================================
#PHASE 3- Merging clouds Implementation
#======================================

#=====================================
#Imports
#======================================
import os
import json
import numpy as np
import open3d as o3d

#=======================================
#Paths
#=======================================
DATA_DIR = "../data"
OUTPUT_DIR = "../web"
TARGET_POINTS = 5000
VOXEL_SIZE = 0.05  

#==================================
#Wall colors used for visualization
#==================================
WALL_COLORS = [
    [1.0, 0.0, 0.0],   #Wall1=Red
    [0.0, 1.0, 0.0],   #Wall2=Green
    [0.0, 0.0, 1.0],   #Wall3=Blue
    [1.0, 1.0, 0.0],   #Wall4=Yellow
]

#===============================
#Wall Specific ICP thresholds 
#===============================
ICP_THRESHOLDS=[0.1, 0.12, 0.1, 0.15]  #Wall1 to Wall4

#================================
#Camera handling
#================================
def load_camera_poses(path):
    #Loading the camera poses from the file
    if not os.path.exists(path):
        print(f"No camera file found: {path}")
        return []
    with open(path, "r") as f:
        data = json.load(f)
    return data["poses"]

def transform_cameras(cam_list, T):
    #Applying transformation matrix T to all camera positions
    new_list = []
    for cam in cam_list:
        pos = np.array(cam["camera_position"] + [1.0])  #Homogeneous coordinates
        transformed_pos = T @ pos
        cam["camera_position"] = transformed_pos[:3].tolist()
        new_list.append(cam)
    return new_list

#==============================================================
#Point cloud handling 
#===============================================================
def load_and_densify(path, target_points=TARGET_POINTS):
    #Loading a point cloud and densifying/downsampling it based on the target point count.
    pcd = o3d.io.read_point_cloud(path)
    pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.2, max_nn=30))
    if len(pcd.points) > target_points:
        pcd = pcd.voxel_down_sample(voxel_size=VOXEL_SIZE)
    return pcd

def compute_fpfh(pcd):
    #Computing FPFH features for a point cloud using a hybrid KD-tree search.
    return o3d.pipelines.registration.compute_fpfh_feature(
        pcd,
        o3d.geometry.KDTreeSearchParamHybrid(radius=0.25, max_nn=100)
    )

def run_ransac(source, target):
    #Computing a coarse global alignment between two point clouds using RANSAC with FPFH features.
    source_fpfh = compute_fpfh(source)
    target_fpfh = compute_fpfh(target)
    distance_threshold = 0.5  
    result = o3d.pipelines.registration.registration_ransac_based_on_feature_matching(
        source, target, source_fpfh, target_fpfh, mutual_filter=True,
        max_correspondence_distance=distance_threshold,
        estimation_method=o3d.pipelines.registration.TransformationEstimationPointToPoint(False),
        ransac_n=4,
        checkers=[
            o3d.pipelines.registration.CorrespondenceCheckerBasedOnEdgeLength(0.9),
            o3d.pipelines.registration.CorrespondenceCheckerBasedOnDistance(distance_threshold)
        ],
        criteria=o3d.pipelines.registration.RANSACConvergenceCriteria(4000000, 1.0)
    )
    return result

def refine_icp(source, target, init_trans=np.identity(4), threshold=0.1, use_point_to_plane=False):
    #Refining point cloud alignment using ICP starting from an initial transformation.
    if use_point_to_plane:
        estimation = o3d.pipelines.registration.TransformationEstimationPointToPlane()
    else:
        estimation = o3d.pipelines.registration.TransformationEstimationPointToPoint()
    result = o3d.pipelines.registration.registration_icp(
        source, target, threshold, init_trans,
        estimation,
        o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=1000)
    )
    return result

def compute_camera_connections(cameras, k=3):
    #Assigning connected_cams using nearest-neighbor distance in 3D for implementing View Graphs
    positions = np.array([cam["camera_position"] for cam in cameras])
    N = len(cameras)

    #Precomputing all pairwise distances
    dist = np.linalg.norm(positions[:, None, :] - positions[None, :, :], axis=2)

    #Filling connected cams
    for i in range(N):
        #Sorting neighbors by distance
        neighbors = np.argsort(dist[i])[1:k+1]
        cameras[i]["connected_cams"] = neighbors.tolist()

    return cameras

#==========================================================
#Merging walls and cameras (with unique camera indices) 
#==========================================================
def merge_walls(wall_files, camera_files):
    merged = None
    merged_cams = []
    cam_counter = 0  #unique index for cameras across all walls

    for i, (pcd_file, cam_file) in enumerate(zip(wall_files, camera_files)):
        print(f"Processing: {pcd_file} with {len(o3d.io.read_point_cloud(pcd_file).points)} points")
        pcd = load_and_densify(pcd_file, TARGET_POINTS)
        pcd.paint_uniform_color(WALL_COLORS[i])
        cameras = load_camera_poses(cam_file)

        #Predefined transformations for Wall2
        if i == 1:
            print("Applied predefined + centroid alignment to Wall2")
            theta = np.radians(5)  #small rotation around Y-axis
            R = np.array([
                [np.cos(theta), 0, np.sin(theta)],
                [0, 1, 0],
                [-np.sin(theta), 0, np.cos(theta)]
            ])
            t = np.array([0.05, 0.0, 0.0])  #small translation
            T_pre = np.eye(4)
            T_pre[:3, :3] = R
            T_pre[:3, 3] = t
            pcd.transform(T_pre)

        if merged is None:
            merged = pcd
            #Assigning unique indices to cameras and wall_id starting from 1
            for cam in cameras:
                cam["index"] = cam_counter
                cam["global_index"] = cam_counter + 1  #adding global index for mapping each camera pose with its respective image
                cam["wall_id"] = i + 1
                cam_counter += 1
            merged_cams.extend(cameras)
            continue

        #Aligning new wall point cloud to merged cloud
        ransac_result = run_ransac(pcd, merged)
        print(f"RANSAC fitness: {ransac_result.fitness:.4f}")

        icp_result = refine_icp(pcd, merged, ransac_result.transformation, threshold=ICP_THRESHOLDS[i])
        print(f"ICP fitness with merged cloud: {icp_result.fitness:.4f}")

        T = icp_result.transformation
        pcd.transform(T)
        merged += pcd

        #Transforming cameras and assigning unique indices and wall_id starting from 1
        cameras_transformed = transform_cameras(cameras, T)
        for cam in cameras_transformed:
            cam["index"] = cam_counter
            cam["global_index"] = cam_counter + 1  #adding global index for mapping each camera pose with its respective image
            cam["wall_id"] = i + 1
            cam_counter += 1
        merged_cams.extend(cameras_transformed)

    #Removing outliers from merged cloud
    merged, _ = merged.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
    print(f"After outlier removal: {len(merged.points)} points")

    return merged, merged_cams

#====================================================
#Visualization
#====================================================
def visualize(merged_pcd, cameras):
    vis = o3d.visualization.Visualizer()
    vis.create_window(window_name="Merged Walls with Cameras", width=1280, height=720)
    vis.add_geometry(merged_pcd)

    for cam in cameras:
        sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.05)
        sphere.paint_uniform_color([1.0, 0.0, 1.0])
        sphere.translate(cam["camera_position"])
        vis.add_geometry(sphere)

    view_control = vis.get_view_control()
    view_control.set_front([0.0, 0.0, -1.0])
    view_control.set_up([0.0, -1.0, 0.0])
    view_control.set_lookat([0.0, 0.0, 0.0])
    view_control.set_zoom(0.8)

    vis.run()
    vis.destroy_window()

#============================================================
#Main 
#============================================================
if __name__ == "__main__":
    wall_files = [
        os.path.join(DATA_DIR, "Wall1_cloudpoint.ply"),
        os.path.join(DATA_DIR, "Wall2_cloudpoint.ply"),
        os.path.join(DATA_DIR, "Wall3_cloudpoint.ply"),
        os.path.join(DATA_DIR, "Wall4_cloudpoint.ply")
    ]

    camera_files = [
        os.path.join(DATA_DIR, "Wall1_cameraposes.json"),
        os.path.join(DATA_DIR, "Wall2_cameraposes.json"),
        os.path.join(DATA_DIR, "Wall3_cameraposes.json"),
        os.path.join(DATA_DIR, "Wall4_cameraposes.json")
    ]

    merged_walls, merged_cams = merge_walls(wall_files, camera_files)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    o3d.io.write_point_cloud(os.path.join(OUTPUT_DIR, "merged_walls.ply"), merged_walls)

    #Computing connected cameras 
    merged_cams = compute_camera_connections(merged_cams, k=3)

    #Saving JSON file
    with open(os.path.join(OUTPUT_DIR, "merged_cameras.json"), "w") as f:
       json.dump(merged_cams, f, indent=2)
    print("Saved merged walls and camera poses!")

    #Saving npy file
    np.save(os.path.join(OUTPUT_DIR, "merged_cameras.npy"), merged_cams)
    visualize(merged_walls, merged_cams)
